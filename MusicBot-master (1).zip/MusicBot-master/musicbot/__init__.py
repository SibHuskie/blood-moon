"""MusicBot bot package."""

import sys


if sys.version_info < (3, 6):
    raise ImportError("MusicBot requires Python 3.6+.")
